package com.uniovi.sdi2223entrega182;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sdi2223Entrega182Application {

	public static void main(String[] args) {
		SpringApplication.run(Sdi2223Entrega182Application.class, args);
	}

}
